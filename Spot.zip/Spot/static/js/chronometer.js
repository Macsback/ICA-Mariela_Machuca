let chronometerInterval;
let chronometerTime = 0; 

function formatTime(seconds) {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return [hrs, mins, secs]
        .map((val) => (val < 10 ? `0${val}` : val))
        .join(":");
}

function startChronometer() {
    if (!chronometerInterval) {
        chronometerInterval = setInterval(() => {
            chronometerTime++;
            document.getElementById("timer").innerText = formatTime(chronometerTime);
        }, 1000);
    }
}


function stopChronometer() {
    clearInterval(chronometerInterval);
    chronometerInterval = null;
}


function resetChronometer() {
    stopChronometer();
    chronometerTime = 0;
    document.getElementById("timer").innerText = "00:00:00";
}

document.getElementById("start-timer").addEventListener("click", startChronometer);
document.getElementById("stop-timer").addEventListener("click", stopChronometer);
document.getElementById("reset-timer").addEventListener("click", resetChronometer);
